/* kunit_manager.h
 *
 * Driver to manage kunit
 *
 * Copyright (C) 2019 Samsung Electronics
 *
 * Sangsu Ha <sangsu.ha@samsung.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 */

#include <linux/kernel.h>
#include <linux/module.h>
#ifdef CONFIG_DRV_SAMSUNG
#include <linux/sec_class.h>
#else
extern struct class *sec_class;
#endif

#include <linux/device.h>

#ifdef CONFIG_KUNIT
#include <kunit/test.h>
#endif

struct kunit_manager_data {
	struct device *dev;
};
